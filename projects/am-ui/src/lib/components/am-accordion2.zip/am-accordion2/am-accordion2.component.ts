import { Component, QueryList, AfterContentInit, ContentChildren, Input, Output, EventEmitter } from '@angular/core';


@Component({
  selector: 'am-accordion2',
  template: `
  <div class="mypanel">
    <div class="title" (click)="toggle.emit()">
      {{title}}
    </div>
    <div class="body" [ngClass]="{'hidden': !opened}">
      <ng-content></ng-content>
    </div>
  <div>
  `,
  styleUrls: ['am-accordion2.component.css'],
  // changeDetection: ChangeDetectionStrategy.OnPush
})
export class AmAccordion2Component {

  @Input() expanded = false;
  @Input() title: string;
  @Output() toggle: EventEmitter<any> = new EventEmitter<any>();
}


@Component({
  selector: 'am-accordions',
  templateUrl: './am-accordion.component.html',
  styleUrls: ['./am-accordion.component.css']
})
export class AmAccordionsComponent implements AfterContentInit {
  @ContentChildren(AmAccordion2Component)
  accordionComponents: QueryList<AmAccordion2Component>;

  /**
   * Invoked when all children  are ready
   */
  ngAfterContentInit() {
    // Set active to first element
    this.accordionComponents.toArray()[0].expanded = true;

    this.accordionComponents.toArray().forEach((acc) => {
      // when title bar is clicked
      // (toggle is an @output event of Group)
      acc.toggle.subscribe(() => {
        // Open the group
        this.expandAccordion(acc);
      });
      /*t.toggle.subscribe((group) => {
        // Open the group
        this.openGroup(group);
      });*/
    });
  }

  /**
   * Open an accordion group
   * @param group   Group instance
   */
  expandAccordion(accordion: AmAccordion2Component) {
    // close other groups
    this.accordionComponents.toArray().forEach((t) => t.expanded = false);
    // open current group
    accordion.expanded = true;
  }
}

