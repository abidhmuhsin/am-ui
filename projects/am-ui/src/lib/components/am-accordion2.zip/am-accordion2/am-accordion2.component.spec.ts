/* tslint:disable:no-unused-variable */
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DebugElement } from '@angular/core';

import { AmAccordion2Component } from './am-accordion2.component';

describe('AmAccordion2Component', () => {
  let component: AmAccordion2Component;
  let fixture: ComponentFixture<AmAccordion2Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AmAccordion2Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AmAccordion2Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
